# VIP BGMI Tournament Manager Bot

## Overview

This is a comprehensive Telegram bot designed to manage BGMI (Battlegrounds Mobile India) gaming tournaments. The bot handles tournament registration, payment processing, player management, and admin controls through an interactive Telegram interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Architecture
- **Bot Framework**: Python-based Telegram bot using `python-telegram-bot` library
- **Database**: MongoDB for persistent data storage
- **Architecture Pattern**: Event-driven with conversation handlers for multi-step user interactions
- **State Management**: In-memory user state tracking with persistent database storage

### Key Technologies
- Python 3.8+
- python-telegram-bot library
- MongoDB with PyMongo driver
- Async/await pattern for non-blocking operations

## Key Components

### 1. Bot Core (`main.py`)
- **Purpose**: Main application entry point and handler setup
- **Architecture**: Centralized handler registration using ConversationHandler pattern
- **Key Features**: 
  - Command routing
  - Conversation state management
  - Error handling and logging

### 2. Database Layer (`database.py`)
- **Purpose**: MongoDB integration and data persistence
- **Collections**: 
  - `users`: User profiles, tournament history, and state tracking
  - `tournaments`: Tournament data, participants, and status
- **Architecture**: Single DatabaseManager class with connection pooling
- **Key Operations**: User management, tournament CRUD, payment tracking

### 3. Handlers (`handlers.py`)
- **Purpose**: Core bot logic and user interaction handling
- **Architecture**: Class-based handler organization with conversation states
- **Key Features**:
  - Multi-step tournament creation
  - Payment confirmation workflows
  - Admin command processing
  - User state management

### 4. Utilities (`utils.py`)
- **Purpose**: Helper functions and common operations
- **Key Functions**:
  - Channel membership verification
  - Admin permission checks
  - Message formatting
  - Input validation and sanitization

### 5. Configuration (`config.py`)
- **Purpose**: Environment variables and message templates
- **Architecture**: Centralized configuration management
- **Key Settings**: Bot token, admin ID, UPI details, MongoDB URI

## Data Flow

### User Registration Flow
1. User starts bot with `/start` command
2. Bot verifies channel membership
3. User presented with tournament registration options
4. Payment process initiated with UPI instructions
5. Admin confirms payment manually
6. User marked as confirmed participant

### Tournament Management Flow
1. Admin creates tournament using `/createtournament` command
2. Tournament details collected through conversation handler
3. Tournament stored in database and posted to channel
4. Users register and make payments
5. Admin sends room details to confirmed players
6. Winners declared and recorded

### Payment Processing Flow
1. User initiates payment with `/paid` command
2. Payment screenshot sent to admin privately
3. Admin reviews and confirms using `/confirm @username`
4. User status updated in database
5. User receives confirmation notification

## External Dependencies

### Required Services
- **Telegram Bot API**: Core bot functionality
- **MongoDB Atlas**: Cloud database service
- **UPI Payment System**: Manual payment verification (screenshot-based)

### Third-party Libraries
- `python-telegram-bot`: Telegram bot framework
- `pymongo`: MongoDB driver
- `asyncio`: Async operations support

### Environment Variables
- `BOT_TOKEN`: Telegram bot authentication
- `ADMIN_ID`: Admin user identification (@Officialbgmi24)
- `UPI_ID`: Payment processing identifier
- `CHANNEL_ID`: Required channel for user verification
- `MONGODB_URI`: Database connection string

## Deployment Strategy

### Current Configuration
- **Environment**: Production ready and running
- **Database**: MongoDB Atlas (cloud-hosted and connected)
- **Hosting**: Running on Replit with continuous deployment
- **Scalability**: Single-instance design with MongoDB for persistence
- **Status**: Bot is live and operational (July 17, 2025)

### Key Considerations
- Bot token and credentials stored in environment variables
- Database connection with retry logic and error handling
- Async operations for handling concurrent user interactions
- Logging configured for monitoring and debugging

### Security Features
- Admin-only commands with ID verification
- Input sanitization and validation
- Channel membership verification
- Manual payment confirmation process

## Notable Design Decisions

### State Management
- **Problem**: Multi-step user interactions (tournament creation, payment process)
- **Solution**: ConversationHandler pattern with state tracking
- **Rationale**: Provides clean user experience for complex workflows

### Payment Processing
- **Problem**: Secure payment handling without direct payment gateway
- **Solution**: Manual screenshot verification by admin
- **Rationale**: Simpler implementation, maintains security through admin oversight

### Database Design
- **Problem**: Need for user tracking and tournament management
- **Solution**: Document-based MongoDB with two main collections
- **Rationale**: Flexible schema for evolving tournament features

### Admin Controls
- **Problem**: Tournament management and user confirmation
- **Solution**: Admin-only commands with ID-based authentication
- **Rationale**: Simple but effective access control mechanism