import pymongo
from pymongo import MongoClient
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging
from config import MONGODB_URI

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        try:
            self.client = MongoClient(MONGODB_URI)
            self.db = self.client.bgmi_tournament_bot
            self.users_collection = self.db.users
            self.tournaments_collection = self.db.tournaments
            
            # Test connection
            self.client.admin.command('ping')
            logger.info("Connected to MongoDB successfully")
            
        except Exception as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            raise

    def close_connection(self):
        """Close the MongoDB connection"""
        if hasattr(self, 'client'):
            self.client.close()

    # User Management
    def create_user(self, user_id: int, username: str = None, first_name: str = None) -> bool:
        """Create a new user or update existing user"""
        try:
            user_data = {
                "user_id": user_id,
                "username": username,
                "first_name": first_name,
                "joined_date": datetime.now(),
                "channel_joined": False,
                "state": "idle",
                "tournaments_joined": [],
                "total_tournaments": 0,
                "total_wins": 0
            }
            
            self.users_collection.update_one(
                {"user_id": user_id},
                {"$set": user_data},
                upsert=True
            )
            return True
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            return False

    def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user by ID"""
        try:
            return self.users_collection.find_one({"user_id": user_id})
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None

    def update_user_state(self, user_id: int, state: str) -> bool:
        """Update user state"""
        try:
            result = self.users_collection.update_one(
                {"user_id": user_id},
                {"$set": {"state": state}}
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error updating user state: {e}")
            return False

    def set_channel_joined(self, user_id: int, joined: bool = True) -> bool:
        """Set user's channel join status"""
        try:
            result = self.users_collection.update_one(
                {"user_id": user_id},
                {"$set": {"channel_joined": joined}}
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error setting channel join status: {e}")
            return False

    def mark_user_paid(self, user_id: int, tournament_id: str) -> bool:
        """Mark user as paid for a tournament"""
        try:
            result = self.users_collection.update_one(
                {"user_id": user_id},
                {
                    "$set": {"state": "payment_sent"},
                    "$addToSet": {"tournaments_joined": tournament_id}
                }
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error marking user as paid: {e}")
            return False

    def confirm_user_payment(self, user_id: int, tournament_id: str) -> bool:
        """Confirm user payment for a tournament"""
        try:
            result = self.users_collection.update_one(
                {"user_id": user_id},
                {"$set": {"state": "confirmed"}}
            )
            
            # Add user to tournament's confirmed players
            self.tournaments_collection.update_one(
                {"_id": tournament_id},
                {"$addToSet": {"confirmed_players": user_id}}
            )
            
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error confirming user payment: {e}")
            return False

    # Tournament Management
    def create_tournament(self, tournament_data: Dict) -> Optional[str]:
        """Create a new tournament"""
        try:
            tournament_data.update({
                "created_date": datetime.now(),
                "status": "active",
                "registered_players": [],
                "confirmed_players": [],
                "room_sent": False
            })
            
            result = self.tournaments_collection.insert_one(tournament_data)
            return str(result.inserted_id)
        except Exception as e:
            logger.error(f"Error creating tournament: {e}")
            return None

    def get_active_tournament(self) -> Optional[Dict]:
        """Get the current active tournament"""
        try:
            return self.tournaments_collection.find_one({"status": "active"})
        except Exception as e:
            logger.error(f"Error getting active tournament: {e}")
            return None

    def get_tournament(self, tournament_id: str) -> Optional[Dict]:
        """Get tournament by ID"""
        try:
            from bson import ObjectId
            return self.tournaments_collection.find_one({"_id": ObjectId(tournament_id)})
        except Exception as e:
            logger.error(f"Error getting tournament: {e}")
            return None

    def add_player_to_tournament(self, tournament_id: str, user_id: int) -> bool:
        """Add a player to tournament's registered players"""
        try:
            from bson import ObjectId
            result = self.tournaments_collection.update_one(
                {"_id": ObjectId(tournament_id)},
                {"$addToSet": {"registered_players": user_id}}
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error adding player to tournament: {e}")
            return False

    def get_confirmed_players(self, tournament_id: str) -> List[int]:
        """Get list of confirmed players for a tournament"""
        try:
            from bson import ObjectId
            tournament = self.tournaments_collection.find_one({"_id": ObjectId(tournament_id)})
            return tournament.get("confirmed_players", []) if tournament else []
        except Exception as e:
            logger.error(f"Error getting confirmed players: {e}")
            return []

    def update_tournament_room(self, tournament_id: str, room_id: str, password: str) -> bool:
        """Update tournament room details"""
        try:
            from bson import ObjectId
            result = self.tournaments_collection.update_one(
                {"_id": ObjectId(tournament_id)},
                {
                    "$set": {
                        "room_id": room_id,
                        "room_password": password,
                        "room_sent": True
                    }
                }
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error updating tournament room: {e}")
            return False

    def close_tournament(self, tournament_id: str) -> bool:
        """Close/end a tournament"""
        try:
            from bson import ObjectId
            result = self.tournaments_collection.update_one(
                {"_id": ObjectId(tournament_id)},
                {"$set": {"status": "completed"}}
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error closing tournament: {e}")
            return False

    def get_user_by_username(self, username: str) -> Optional[Dict]:
        """Get user by username"""
        try:
            # Remove @ if present
            username = username.lstrip('@')
            return self.users_collection.find_one({"username": username})
        except Exception as e:
            logger.error(f"Error getting user by username: {e}")
            return None

    def update_user_stats(self, user_id: int, position: int) -> bool:
        """Update user tournament statistics"""
        try:
            update_data = {"$inc": {"total_tournaments": 1}}
            if position == 1:
                update_data["$inc"]["total_wins"] = 1
            
            result = self.users_collection.update_one(
                {"user_id": user_id},
                update_data
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error updating user stats: {e}")
            return False

# Global database instance
db_manager = DatabaseManager()
