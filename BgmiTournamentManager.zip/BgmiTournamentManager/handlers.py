import asyncio
import logging
from typing import Dict, Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

from database import db_manager
from utils import (
    check_channel_membership, is_admin, format_tournament_post,
    format_payment_instructions, format_room_details, format_winners_announcement,
    validate_tournament_data, parse_tournament_input, parse_winners_input,
    format_user_list, log_user_action, log_admin_action, is_valid_username,
    sanitize_input
)
from config import (
    WELCOME_MESSAGE, RULES_TEXT, DISCLAIMER_TEXT, CHANNEL_ID, UPI_ID,
    UserState, AdminState
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Conversation states
TOURNAMENT_NAME, TOURNAMENT_DATE, TOURNAMENT_TIME, TOURNAMENT_FEE, TOURNAMENT_PRIZE, TOURNAMENT_MAP = range(6)
CONFIRM_USERNAME = range(1)
ROOM_ID, ROOM_PASSWORD = range(2)
WINNER_DATA = range(1)

class TournamentHandlers:
    def __init__(self):
        self.user_states: Dict[int, str] = {}
        self.admin_states: Dict[int, str] = {}
        self.temp_data: Dict[int, Dict] = {}

    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        
        # Create or update user in database
        db_manager.create_user(
            user_id=user.id,
            username=user.username,
            first_name=user.first_name
        )
        
        # Check if user has joined the channel
        if await check_channel_membership(context.bot, user.id, CHANNEL_ID):
            db_manager.set_channel_joined(user.id, True)
            await self.show_main_menu(update, context)
        else:
            await update.message.reply_text(
                WELCOME_MESSAGE,
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True
            )
        
        log_user_action(user.id, "start_command")

    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Show main menu to user"""
        user = update.effective_user
        
        # Check for active tournament
        active_tournament = db_manager.get_active_tournament()
        
        if active_tournament:
            keyboard = [
                [InlineKeyboardButton("✅ Join Tournament", callback_data=f"join_{active_tournament['_id']}")],
                [InlineKeyboardButton("📜 Rules", callback_data="rules")],
                [InlineKeyboardButton("⚠️ Disclaimer", callback_data="disclaimer")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            tournament_post = format_tournament_post(active_tournament)
            await update.message.reply_text(
                tournament_post,
                reply_markup=reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await update.message.reply_text(
                "🎮 **Welcome to VIP BGMI Tournament Manager!**\n\n"
                "🔍 No active tournaments at the moment.\n"
                "📢 Stay tuned for upcoming tournaments!\n\n"
                "🔔 Turn on notifications to get notified when new tournaments are announced.",
                parse_mode=ParseMode.MARKDOWN
            )

    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle button callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        data = query.data
        
        if data == "rules":
            await query.edit_message_text(
                RULES_TEXT,
                parse_mode=ParseMode.MARKDOWN
            )
        elif data == "disclaimer":
            await query.edit_message_text(
                DISCLAIMER_TEXT,
                parse_mode=ParseMode.MARKDOWN
            )
        elif data.startswith("join_"):
            tournament_id = data.split("_")[1]
            await self.handle_tournament_join(query, tournament_id, context)
        
        log_user_action(user_id, "button_callback", data)

    async def handle_tournament_join(self, query, tournament_id: str, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle tournament join request"""
        user_id = query.from_user.id
        
        # Check if user has joined the channel
        if not await check_channel_membership(context.bot, user_id, CHANNEL_ID):
            await query.edit_message_text(
                f"❌ You must join our channel first!\n\n"
                f"👉 [Join Channel](https://t.me/{CHANNEL_ID})\n\n"
                f"After joining, click /start again.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Get tournament details
        tournament = db_manager.get_tournament(tournament_id)
        if not tournament:
            await query.edit_message_text("❌ Tournament not found!")
            return
        
        # Check if user is already registered
        user_data = db_manager.get_user(user_id)
        if tournament_id in user_data.get("tournaments_joined", []):
            await query.edit_message_text(
                "✅ You are already registered for this tournament!\n\n"
                "🔄 Current status: Waiting for confirmation\n"
                "📱 Check your DMs for payment instructions."
            )
            return
        
        # Add user to tournament
        db_manager.add_player_to_tournament(tournament_id, user_id)
        db_manager.update_user_state(user_id, UserState.WAITING_FOR_PAYMENT)
        
        # Send payment instructions
        payment_msg = format_payment_instructions(tournament["entry_fee"], UPI_ID)
        await context.bot.send_message(
            chat_id=user_id,
            text=payment_msg,
            parse_mode=ParseMode.MARKDOWN
        )
        
        await query.edit_message_text(
            "📱 **Payment instructions sent to your DM!**\n\n"
            "💰 Please complete the payment and click /paid after sending the screenshot to admin.",
            parse_mode=ParseMode.MARKDOWN
        )

    async def paid_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /paid command"""
        user = update.effective_user
        user_id = user.id
        
        # Check if user has an active tournament registration
        active_tournament = db_manager.get_active_tournament()
        if not active_tournament:
            await update.message.reply_text("❌ No active tournament found!")
            return
        
        user_data = db_manager.get_user(user_id)
        if not user_data or str(active_tournament["_id"]) not in user_data.get("tournaments_joined", []):
            await update.message.reply_text("❌ You haven't registered for this tournament yet!")
            return
        
        # Mark user as paid
        db_manager.mark_user_paid(user_id, str(active_tournament["_id"]))
        
        # Notify admin
        admin_message = (
            f"🧾 **Join Request**\n\n"
            f"👤 **User:** @{user.username or 'No username'} ({user.first_name})\n"
            f"🆔 **ID:** {user_id}\n"
            f"🎮 **Tournament:** {active_tournament['name']}\n"
            f"💰 **Amount:** ₹{active_tournament['entry_fee']}\n\n"
            f"⏳ **Status:** Awaiting Confirmation\n\n"
            f"Use /confirm @{user.username or user_id} to confirm payment."
        )
        
        await context.bot.send_message(
            chat_id=context.bot_data.get("admin_id", 7891142412),
            text=admin_message,
            parse_mode=ParseMode.MARKDOWN
        )
        
        await update.message.reply_text(
            "✅ **Payment notification sent!**\n\n"
            "📸 Make sure you've sent the payment screenshot to the admin\n"
            "⏳ Your registration is now pending confirmation\n\n"
            "🔔 You'll be notified once your payment is confirmed!"
        )
        
        log_user_action(user_id, "paid_command")

    # Admin Commands
    async def create_tournament_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start tournament creation process"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ This command is for admins only!")
            return ConversationHandler.END
        
        await update.message.reply_text(
            "🎮 **Create New Tournament**\n\n"
            "📝 Please provide the following information (one per line):\n\n"
            "1. Tournament Name\n"
            "2. Date (YYYY-MM-DD)\n"
            "3. Time (e.g., 9:00 PM)\n"
            "4. Entry Fee (numbers only)\n"
            "5. Prize Pool (numbers only)\n"
            "6. Map Name\n\n"
            "**Example:**\n"
            "Sunday Showdown\n"
            "2025-07-20\n"
            "9:00 PM\n"
            "50\n"
            "500\n"
            "Erangel",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return TOURNAMENT_NAME

    async def process_tournament_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Process tournament creation data"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Parse tournament data
        tournament_data = parse_tournament_input(message_text)
        if not tournament_data:
            await update.message.reply_text(
                "❌ Invalid format! Please provide all 6 fields in the correct format.\n\n"
                "Make sure you provide exactly 6 lines:\n"
                "1. Tournament Name\n"
                "2. Date (YYYY-MM-DD)\n"
                "3. Time\n"
                "4. Entry Fee (numbers only)\n"
                "5. Prize Pool (numbers only)\n"
                "6. Map Name\n\n"
                "Use /createtournament to try again."
            )
            return ConversationHandler.END
        
        # Validate data
        validation_error = validate_tournament_data(tournament_data)
        if validation_error:
            await update.message.reply_text(
                f"❌ {validation_error}\n\n"
                "Use /createtournament to try again."
            )
            return ConversationHandler.END
        
        # Add UPI ID
        tournament_data["upi_id"] = UPI_ID
        
        # Create tournament
        tournament_id = db_manager.create_tournament(tournament_data)
        if not tournament_id:
            await update.message.reply_text("❌ Failed to create tournament. Please try again.")
            return ConversationHandler.END
        
        # Send confirmation to admin
        tournament_post = format_tournament_post(tournament_data)
        await update.message.reply_text(
            f"✅ **Tournament Created Successfully!**\n\n"
            f"{tournament_post}\n\n"
            f"🆔 **Tournament ID:** {tournament_id}\n"
            f"📢 Tournament is now active and players can join!",
            parse_mode=ParseMode.MARKDOWN
        )
        
        log_admin_action(user_id, "create_tournament", tournament_data["name"])
        return ConversationHandler.END

    async def confirm_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /confirm command"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ This command is for admins only!")
            return
        
        # Extract username from command
        if not context.args:
            await update.message.reply_text(
                "❌ Please provide a username!\n\n"
                "**Usage:** /confirm @username"
            )
            return
        
        username = context.args[0].lstrip('@')
        
        # Get user by username
        user_data = db_manager.get_user_by_username(username)
        if not user_data:
            await update.message.reply_text(f"❌ User @{username} not found!")
            return
        
        # Get active tournament
        active_tournament = db_manager.get_active_tournament()
        if not active_tournament:
            await update.message.reply_text("❌ No active tournament found!")
            return
        
        # Confirm user payment
        success = db_manager.confirm_user_payment(user_data["user_id"], str(active_tournament["_id"]))
        if success:
            # Send confirmation to user
            await context.bot.send_message(
                chat_id=user_data["user_id"],
                text=(
                    "✅ **Payment Confirmed!**\n\n"
                    "🎉 You're now registered for the tournament!\n"
                    "🎮 Room details will be shared before match time.\n\n"
                    "📱 Keep notifications on to receive updates!"
                ),
                parse_mode=ParseMode.MARKDOWN
            )
            
            await update.message.reply_text(
                f"✅ **Payment confirmed for @{username}!**\n\n"
                f"📱 User has been notified."
            )
        else:
            await update.message.reply_text("❌ Failed to confirm payment. Please try again.")
        
        log_admin_action(user_id, "confirm_payment", username)

    async def send_room_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start room details sending process"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ This command is for admins only!")
            return ConversationHandler.END
        
        # Get active tournament
        active_tournament = db_manager.get_active_tournament()
        if not active_tournament:
            await update.message.reply_text("❌ No active tournament found!")
            return ConversationHandler.END
        
        # Get confirmed players count
        confirmed_players = db_manager.get_confirmed_players(str(active_tournament["_id"]))
        
        if not confirmed_players:
            await update.message.reply_text("❌ No confirmed players found!")
            return ConversationHandler.END
        
        self.temp_data[user_id] = {"tournament_id": str(active_tournament["_id"])}
        
        await update.message.reply_text(
            f"🎮 **Send Room Details**\n\n"
            f"📊 **Tournament:** {active_tournament['name']}\n"
            f"👥 **Confirmed Players:** {len(confirmed_players)}\n\n"
            f"📝 Please provide room details (one per line):\n\n"
            f"1. Room ID\n"
            f"2. Room Password\n\n"
            f"**Example:**\n"
            f"123456\n"
            f"vip50",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return ROOM_ID

    async def process_room_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Process room details"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        lines = message_text.strip().split('\n')
        if len(lines) < 2:
            await update.message.reply_text(
                "❌ Invalid format! Please provide both Room ID and Password.\n\n"
                "Use /sendroom to try again."
            )
            return ConversationHandler.END
        
        room_id = lines[0].strip()
        password = lines[1].strip()
        
        tournament_id = self.temp_data[user_id]["tournament_id"]
        
        # Update tournament with room details
        db_manager.update_tournament_room(tournament_id, room_id, password)
        
        # Get tournament details
        tournament = db_manager.get_tournament(tournament_id)
        confirmed_players = db_manager.get_confirmed_players(tournament_id)
        
        # Send room details to all confirmed players
        room_message = format_room_details(room_id, password, tournament["time"])
        
        sent_count = 0
        for player_id in confirmed_players:
            try:
                await context.bot.send_message(
                    chat_id=player_id,
                    text=room_message,
                    parse_mode=ParseMode.MARKDOWN
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Failed to send room details to {player_id}: {e}")
        
        await update.message.reply_text(
            f"✅ **Room details sent successfully!**\n\n"
            f"📱 **Sent to:** {sent_count}/{len(confirmed_players)} players\n"
            f"🎮 **Room ID:** {room_id}\n"
            f"🔑 **Password:** {password}\n\n"
            f"⚠️ **Note:** No refunds will be processed after this point."
        )
        
        # Clear temp data
        del self.temp_data[user_id]
        
        log_admin_action(user_id, "send_room_details", f"Room ID: {room_id}")
        return ConversationHandler.END

    async def declare_winners_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Start winners declaration process"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ This command is for admins only!")
            return ConversationHandler.END
        
        await update.message.reply_text(
            "🏆 **Declare Winners**\n\n"
            "📝 Please provide winner details (one per line):\n\n"
            "1. 1st Place Username\n"
            "2. 1st Place Points\n"
            "3. 1st Place Prize\n"
            "4. 2nd Place Username\n"
            "5. 2nd Place Points\n"
            "6. 2nd Place Prize\n"
            "7. 3rd Place Username\n"
            "8. 3rd Place Points\n"
            "9. 3rd Place Prize\n\n"
            "**Example:**\n"
            "rahul_gamer\n"
            "22\n"
            "250\n"
            "pro_player\n"
            "18\n"
            "150\n"
            "noob_killer\n"
            "15\n"
            "100",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return WINNER_DATA

    async def process_winners_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Process winners declaration data"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Parse winners data
        winners_data = parse_winners_input(message_text)
        if not winners_data:
            await update.message.reply_text(
                "❌ Invalid format! Please provide all 9 fields in the correct format.\n\n"
                "Use /declarewinners to try again."
            )
            return ConversationHandler.END
        
        # Get active tournament
        active_tournament = db_manager.get_active_tournament()
        if not active_tournament:
            await update.message.reply_text("❌ No active tournament found!")
            return ConversationHandler.END
        
        # Format winners announcement
        winners_message = format_winners_announcement(winners_data)
        
        # Send to group (assuming the bot is in a group)
        try:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=winners_message,
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Failed to send winners announcement: {e}")
        
        # Update user statistics
        for position, winner_key in enumerate(["first", "second", "third"], 1):
            username = winners_data[winner_key]["username"]
            user_data = db_manager.get_user_by_username(username)
            if user_data:
                db_manager.update_user_stats(user_data["user_id"], position)
        
        # Close tournament
        db_manager.close_tournament(str(active_tournament["_id"]))
        
        await update.message.reply_text(
            "✅ **Winners declared successfully!**\n\n"
            "🏆 Tournament has been completed and closed.\n"
            "📊 User statistics have been updated."
        )
        
        log_admin_action(user_id, "declare_winners", active_tournament["name"])
        return ConversationHandler.END

    async def list_players_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /listplayers command"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ This command is for admins only!")
            return
        
        # Get active tournament
        active_tournament = db_manager.get_active_tournament()
        if not active_tournament:
            await update.message.reply_text("❌ No active tournament found!")
            return
        
        # Get confirmed players
        confirmed_players = db_manager.get_confirmed_players(str(active_tournament["_id"]))
        
        if not confirmed_players:
            await update.message.reply_text("❌ No confirmed players found!")
            return
        
        # Get user details for each player
        players_data = []
        for player_id in confirmed_players:
            user_data = db_manager.get_user(player_id)
            if user_data:
                players_data.append(user_data)
        
        # Format player list
        player_list = format_user_list(players_data)
        
        await update.message.reply_text(
            f"📋 **Tournament Players List**\n\n"
            f"🎮 **Tournament:** {active_tournament['name']}\n"
            f"👥 **Total Confirmed:** {len(players_data)}\n\n"
            f"{player_list}",
            parse_mode=ParseMode.MARKDOWN
        )
        
        log_admin_action(user_id, "list_players")

    async def cancel_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
        """Cancel current operation"""
        await update.message.reply_text("❌ Operation cancelled.")
        return ConversationHandler.END


