import os
from typing import Dict, Any

# Bot Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN", "7911618551:AAHzOkwAzvcLstjyUJWUFs5oaH53iRzYE7s")
ADMIN_ID = int(os.getenv("ADMIN_ID", "7891142412"))
UPI_ID = os.getenv("UPI_ID", "8435010927@ybl")
CHANNEL_ID = os.getenv("CHANNEL_ID", "officialBgmiturnament")
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://rahul7241146384:rahul7241146384@cluster0.qeaogc4.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

# Message Templates
WELCOME_MESSAGE = """🎮 **Welcome to VIP BGMI Tournament Manager!** 🎮

🔥 Ready to dominate the battleground? 

⚠️ **Before you can register for tournaments, you must join our official channel:**

👇 **Join Channel First** 👇
[Click Here to Join](https://t.me/officialBgmiturnament)

After joining, click /start again to access the registration system!

🏆 **Features:**
• 🎯 Tournament Registration
• 💰 Secure Payment Processing
• 🏅 Winner Announcements
• 📊 Live Updates

Let's get that chicken dinner! 🍗"""

TOURNAMENT_POST_TEMPLATE = """🎮 **TOURNAMENT ALERT** 🎮

🏆 **{name}**
📅 **Date:** {date}
🕘 **Time:** {time}
📍 **Map:** {map}
💰 **Entry Fee:** ₹{entry_fee}
🎁 **Prize Pool:** ₹{prize_pool}

👇 **Click to Join** 👇"""

PAYMENT_INSTRUCTIONS = """💳 **PAYMENT INSTRUCTIONS**

💰 **Amount:** ₹{amount}
🔗 **UPI ID:** `{upi_id}`

📸 **Steps:**
1. Pay ₹{amount} to the UPI ID above
2. Take a screenshot of the payment
3. Send the screenshot to @Officialbgmi24
4. Click /paid after sending the screenshot

⚠️ **Important:** Payment confirmation is required within 30 minutes!"""

RULES_TEXT = """📜 **TOURNAMENT RULES**

1️⃣ **No emulator players allowed**
2️⃣ **No teaming, hacking, or glitching**
3️⃣ **Kill + Rank = Points**
4️⃣ **Room closes on time. Be punctual**
5️⃣ **Follow fair play guidelines**
6️⃣ **Admin's decision is final**

🚫 **Violation of rules will result in disqualification**"""

DISCLAIMER_TEXT = """⚠️ **DISCLAIMER**

🚫 **No refunds after room details are shared**
📶 **Admin not responsible for lag/disconnect issues**
🔒 **Cheaters will be banned permanently**
📱 **Ensure stable internet connection**
✅ **By joining, you accept all rules & risks**

**Good luck and have fun!** 🎮"""

ROOM_DETAILS_TEMPLATE = """🎮 **ROOM DETAILS**

🆔 **Room ID:** `{room_id}`
🔑 **Password:** `{password}`
🕘 **Time:** {time}

⚠️ **IMPORTANT:**
• Do not share these details with anyone
• No refunds after room details are sent
• Join the room 5 minutes before the scheduled time

**Good luck, soldier!** 🎯"""

WINNERS_TEMPLATE = """🏆 **TOURNAMENT WINNERS**

🥇 **1st Place:** @{first_user} — {first_points} pts — ₹{first_prize}
🥈 **2nd Place:** @{second_user} — {second_points} pts — ₹{second_prize}
🥉 **3rd Place:** @{third_user} — {third_points} pts — ₹{third_prize}

🎉 **Congratulations to all winners!**
💰 **Prizes will be distributed within 24 hours**

**Thanks for participating!** 🎮"""

# User States
class UserState:
    WAITING_FOR_CHANNEL_JOIN = "waiting_for_channel_join"
    IDLE = "idle"
    WAITING_FOR_PAYMENT = "waiting_for_payment"
    PAYMENT_SENT = "payment_sent"
    CONFIRMED = "confirmed"

# Admin States
class AdminState:
    CREATING_TOURNAMENT = "creating_tournament"
    WAITING_FOR_TOURNAMENT_DATA = "waiting_for_tournament_data"
    WAITING_FOR_CONFIRMATION = "waiting_for_confirmation"
    WAITING_FOR_ROOM_DETAILS = "waiting_for_room_details"
    WAITING_FOR_WINNERS = "waiting_for_winners"
