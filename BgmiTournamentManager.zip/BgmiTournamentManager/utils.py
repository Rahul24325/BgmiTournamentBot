import logging
from datetime import datetime
from typing import Dict, Optional, List
from telegram import Bot, ChatMember
from config import CHANNEL_ID, ADMIN_ID

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_channel_membership(bot: Bot, user_id: int, channel_id: str) -> bool:
    """Check if user is a member of the required channel"""
    try:
        # Get chat member status
        member = await bot.get_chat_member(chat_id=f"@{channel_id}", user_id=user_id)
        
        # Check if user is a member (not left or kicked)
        # Use string comparison instead of constants for compatibility
        return member.status not in ["left", "kicked"]
    except Exception as e:
        logger.error(f"Error checking channel membership: {e}")
        return False

def is_admin(user_id: int) -> bool:
    """Check if user is an admin"""
    return user_id == ADMIN_ID

def format_tournament_post(tournament_data: Dict) -> str:
    """Format tournament data for posting"""
    from config import TOURNAMENT_POST_TEMPLATE
    
    return TOURNAMENT_POST_TEMPLATE.format(
        name=tournament_data["name"],
        date=tournament_data["date"],
        time=tournament_data["time"],
        map=tournament_data["map"],
        entry_fee=tournament_data["entry_fee"],
        prize_pool=tournament_data["prize_pool"]
    )

def format_payment_instructions(amount: int, upi_id: str) -> str:
    """Format payment instructions"""
    from config import PAYMENT_INSTRUCTIONS
    
    return PAYMENT_INSTRUCTIONS.format(
        amount=amount,
        upi_id=upi_id
    )

def format_room_details(room_id: str, password: str, time: str) -> str:
    """Format room details message"""
    from config import ROOM_DETAILS_TEMPLATE
    
    return ROOM_DETAILS_TEMPLATE.format(
        room_id=room_id,
        password=password,
        time=time
    )

def format_winners_announcement(winners_data: Dict) -> str:
    """Format winners announcement"""
    from config import WINNERS_TEMPLATE
    
    return WINNERS_TEMPLATE.format(
        first_user=winners_data["first"]["username"],
        first_points=winners_data["first"]["points"],
        first_prize=winners_data["first"]["prize"],
        second_user=winners_data["second"]["username"],
        second_points=winners_data["second"]["points"],
        second_prize=winners_data["second"]["prize"],
        third_user=winners_data["third"]["username"],
        third_points=winners_data["third"]["points"],
        third_prize=winners_data["third"]["prize"]
    )

def validate_tournament_data(data: Dict) -> Optional[str]:
    """Validate tournament creation data"""
    required_fields = ["name", "date", "time", "entry_fee", "prize_pool", "map"]
    
    for field in required_fields:
        if field not in data or not data[field]:
            return f"Missing required field: {field}"
    
    # Validate numeric fields
    try:
        int(data["entry_fee"])
        int(data["prize_pool"])
    except ValueError:
        return "Entry fee and prize pool must be numeric values"
    
    # Validate date format (basic check)
    try:
        datetime.strptime(data["date"], "%Y-%m-%d")
    except ValueError:
        return "Invalid date format. Use YYYY-MM-DD format"
    
    return None

def parse_tournament_input(message_text: str) -> Optional[Dict]:
    """Parse tournament creation input from admin message"""
    lines = [line.strip() for line in message_text.strip().split('\n') if line.strip()]
    
    if len(lines) < 6:
        return None
    
    try:
        # Extract numeric values more flexibly
        entry_fee_str = lines[3].strip()
        prize_pool_str = lines[4].strip()
        
        # Remove any non-numeric characters except digits
        entry_fee = int(''.join(filter(str.isdigit, entry_fee_str)))
        prize_pool = int(''.join(filter(str.isdigit, prize_pool_str)))
        
        tournament_data = {
            "name": lines[0].strip(),
            "date": lines[1].strip(),
            "time": lines[2].strip(),
            "entry_fee": entry_fee,
            "prize_pool": prize_pool,
            "map": lines[5].strip()
        }
        
        return tournament_data
    except (ValueError, IndexError):
        return None

def parse_winners_input(message_text: str) -> Optional[Dict]:
    """Parse winners announcement input from admin"""
    lines = message_text.strip().split('\n')
    
    if len(lines) < 9:  # 3 lines per winner (username, points, prize)
        return None
    
    try:
        winners_data = {
            "first": {
                "username": lines[0].strip().lstrip('@'),
                "points": int(lines[1].strip()),
                "prize": int(lines[2].strip())
            },
            "second": {
                "username": lines[3].strip().lstrip('@'),
                "points": int(lines[4].strip()),
                "prize": int(lines[5].strip())
            },
            "third": {
                "username": lines[6].strip().lstrip('@'),
                "points": int(lines[7].strip()),
                "prize": int(lines[8].strip())
            }
        }
        
        return winners_data
    except (ValueError, IndexError):
        return None

def escape_markdown(text: str) -> str:
    """Escape special characters for Markdown"""
    special_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text

def format_user_list(users: List[Dict]) -> str:
    """Format list of users for admin"""
    if not users:
        return "No players registered yet."
    
    user_list = "📋 **Confirmed Players:**\n\n"
    for i, user in enumerate(users, 1):
        username = user.get("username", "No username")
        first_name = user.get("first_name", "Unknown")
        user_list += f"{i}. @{username} ({first_name})\n"
    
    return user_list

def log_user_action(user_id: int, action: str, details: str = ""):
    """Log user actions for debugging"""
    logger.info(f"User {user_id} performed action: {action} - {details}")

def log_admin_action(admin_id: int, action: str, details: str = ""):
    """Log admin actions for debugging"""
    logger.info(f"Admin {admin_id} performed action: {action} - {details}")

def get_current_timestamp() -> str:
    """Get current timestamp as string"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def format_datetime(dt: datetime) -> str:
    """Format datetime for display"""
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def is_valid_username(username: str) -> bool:
    """Check if username is valid (basic validation)"""
    if not username:
        return False
    
    # Remove @ if present
    username = username.lstrip('@')
    
    # Basic validation: alphanumeric and underscore only
    return username.replace('_', '').isalnum() and len(username) >= 3

def sanitize_input(text: str) -> str:
    """Sanitize user input"""
    if not text:
        return ""
    
    # Remove potentially harmful characters
    return text.strip()[:500]  # Limit length to prevent spam
