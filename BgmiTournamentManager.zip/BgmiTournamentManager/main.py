import logging
import asyncio
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters
)
from telegram.constants import ParseMode

from config import BOT_TOKEN, ADMIN_ID
from handlers import TournamentHandlers, TOURNAMENT_NAME, ROOM_ID, WINNER_DATA
from database import db_manager

# Create global handlers instance
handlers = TournamentHandlers()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class BGMITournamentBot:
    def __init__(self):
        self.application = Application.builder().token(BOT_TOKEN).build()
        self.setup_handlers()

    def setup_handlers(self):
        """Setup all command and message handlers"""
        
        # Store admin ID in bot data
        self.application.bot_data["admin_id"] = ADMIN_ID
        
        # Basic commands
        self.application.add_handler(CommandHandler("start", handlers.start_command))
        self.application.add_handler(CommandHandler("paid", handlers.paid_command))
        self.application.add_handler(CommandHandler("confirm", handlers.confirm_command))
        self.application.add_handler(CommandHandler("listplayers", handlers.list_players_command))
        
        # Conversation handler for tournament creation
        create_tournament_handler = ConversationHandler(
            entry_points=[CommandHandler("createtournament", handlers.create_tournament_command)],
            states={
                TOURNAMENT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.process_tournament_data)],
            },
            fallbacks=[CommandHandler("cancel", handlers.cancel_command)],
        )
        self.application.add_handler(create_tournament_handler)
        
        # Conversation handler for sending room details
        send_room_handler = ConversationHandler(
            entry_points=[CommandHandler("sendroom", handlers.send_room_command)],
            states={
                ROOM_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.process_room_details)],
            },
            fallbacks=[CommandHandler("cancel", handlers.cancel_command)],
        )
        self.application.add_handler(send_room_handler)
        
        # Conversation handler for declaring winners
        declare_winners_handler = ConversationHandler(
            entry_points=[CommandHandler("declarewinners", handlers.declare_winners_command)],
            states={
                WINNER_DATA: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.process_winners_data)],
            },
            fallbacks=[CommandHandler("cancel", handlers.cancel_command)],
        )
        self.application.add_handler(declare_winners_handler)
        
        # Callback query handler for inline buttons
        self.application.add_handler(CallbackQueryHandler(handlers.button_callback))
        
        # Error handler
        self.application.add_error_handler(self.error_handler)

    async def error_handler(self, update, context):
        """Handle errors"""
        logger.error(f"Exception while handling an update: {context.error}")
        
        try:
            if update and update.effective_chat:
                await update.effective_chat.send_message(
                    "❌ An error occurred while processing your request. Please try again later."
                )
        except Exception as e:
            logger.error(f"Failed to send error message: {e}")

    async def post_init(self, application):
        """Initialize bot after startup"""
        logger.info("Bot initialized successfully")
        
        # Send startup message to admin
        try:
            await application.bot.send_message(
                chat_id=ADMIN_ID,
                text="🤖 **VIP BGMI Tournament Bot Started!**\n\n"
                     "✅ Bot is online and ready to manage tournaments.\n"
                     "📱 All systems operational.",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Failed to send startup message: {e}")

    async def post_shutdown(self, application):
        """Cleanup after shutdown"""
        logger.info("Bot shutting down...")
        
        # Close database connection
        try:
            db_manager.close_connection()
            logger.info("Database connection closed")
        except Exception as e:
            logger.error(f"Error closing database connection: {e}")
        
        # Send shutdown message to admin
        try:
            await application.bot.send_message(
                chat_id=ADMIN_ID,
                text="🔴 **VIP BGMI Tournament Bot Shutdown**\n\n"
                     "⏹️ Bot is going offline.\n"
                     "🔧 Maintenance mode activated.",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Failed to send shutdown message: {e}")

    def run(self):
        """Run the bot"""
        logger.info("Starting VIP BGMI Tournament Bot...")
        
        # Add post init and shutdown handlers
        self.application.post_init = self.post_init
        self.application.post_shutdown = self.post_shutdown
        
        # Start the bot
        self.application.run_polling(
            allowed_updates=["message", "callback_query"],
            drop_pending_updates=True
        )

def main():
    """Main function"""
    try:
        bot = BGMITournamentBot()
        bot.run()
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        raise

if __name__ == "__main__":
    main()
