# VIP BGMI Tournament Manager Bot

A comprehensive Telegram bot for managing BGMI (Battlegrounds Mobile India) gaming tournaments with payment processing, player management, and admin controls.

## Features

### User Features
- **Tournament Registration**: Join active tournaments with payment verification
- **Channel Verification**: Ensures users join the official channel before registration
- **Payment Processing**: Secure UPI payment integration with screenshot verification
- **Real-time Updates**: Get notified about tournament status and room details
- **Interactive Interface**: Easy-to-use inline buttons for navigation

### Admin Features
- **Tournament Management**: Create and manage tournaments with all details
- **Player Management**: Confirm payments and manage player lists
- **Room Distribution**: Send room details to confirmed players privately
- **Winner Announcements**: Declare winners with prizes and points
- **Statistics Tracking**: Track user tournament participation and wins

## Commands

### User Commands
- `/start` - Welcome message and channel verification
- `/paid` - Confirm payment after sending screenshot to admin

### Admin Commands
- `/createtournament` - Create a new tournament
- `/confirm @username` - Confirm user payment
- `/sendroom` - Send room details to confirmed players
- `/declarewinners` - Announce tournament winners
- `/listplayers` - List all confirmed players

## Setup Instructions

### Prerequisites
- Python 3.8 or higher
- MongoDB database
- Telegram Bot Token
- Admin Telegram ID

### Installation

1. **Clone the repository:**
```bash
git clone <repository-url>
cd bgmi-tournament-bot
